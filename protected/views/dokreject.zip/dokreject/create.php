<?php
/* @var $this DokrejectController */
/* @var $model Dokreject */

$this->breadcrumbs=array(
	'Dokrejects'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Dokreject', 'url'=>array('index')),
	array('label'=>'Manage Dokreject', 'url'=>array('admin')),
);
?>

<h1>Create Dokreject</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>